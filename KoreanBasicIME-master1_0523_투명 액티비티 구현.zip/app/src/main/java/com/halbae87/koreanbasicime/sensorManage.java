package com.halbae87.koreanbasicime;

import android.app.Activity;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


public class sensorManage extends Activity implements SensorEventListener {

    public static Context sContext;
    public static android.hardware.SensorManager sm;
    public Sensor sensor;
    public float axis_X;
    public float axis_Y;
    public float axis_Z;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_manage);
        sContext = this;

        sm = (SensorManager) getSystemService(sContext.SENSOR_SERVICE);
        sensor = sm.getDefaultSensor(Sensor.TYPE_ORIENTATION);
        finish();

    }
    public void onResume(){
        super.onResume();
        sm.registerListener((SensorEventListener)sContext,sensor,sm.SENSOR_DELAY_FASTEST);
    }
    public void onPause(){
        super.onPause();
        sm.unregisterListener((SensorEventListener)sContext);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        //Log.d("메소드 호출","onSensorChanged 메소드 호출");
        if (event.sensor.getType() == Sensor.TYPE_ORIENTATION){
            axis_X = event.values[0];
            axis_Y = event.values[1];
            axis_Z = event.values[2];
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {

    }
}