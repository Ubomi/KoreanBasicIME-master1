package com.halbae87.koreanbasicime;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;


public class MainActivity extends Activity{
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);


        //this.startService(new Intent(this,SoftKeyboard.class));
        startService(new Intent(getApplicationContext(),SoftKeyboard.class));
        Log.d("start activity","here");


        finish();
    }
}

