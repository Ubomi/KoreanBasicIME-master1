package com.halbae87.koreanbasicime;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;


public class MainActivity extends AppCompatActivity implements SensorEventListener{

    public static Context mContext;
    public SensorManager sm;
    public Sensor sensor;
    public float axis_X;
    public float axis_Y;
    public float axis_Z;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);

        mContext = this;
        // Sensor part
        sm = (SensorManager)getSystemService(mContext.SENSOR_SERVICE); //감각 센서 등록하기
        sensor = sm.getDefaultSensor(Sensor.TYPE_ORIENTATION);// 방향센서 특정으로 가져오기

        startService(new Intent(getApplicationContext(),SoftKeyboard.class));
        //Log.d("start activity","here");

        //finish();
    }

    public void onResume(){
        super.onResume();
        //Log.d("메소드 호출","onResume 메소드 호출");
        sm.registerListener((SensorEventListener) mContext,sensor,sm.SENSOR_DELAY_FASTEST);
    }

    public void onPause(){
        super.onPause();
        //Log.d("메소드 호출","onPause 메소드 호출");
        sm.unregisterListener((SensorEventListener) mContext);
    }

    public void onSensorChanged(SensorEvent event){
        //Log.d("메소드 호출","onSensorChanged 메소드 호출");
        if (event.sensor.getType() == Sensor.TYPE_ORIENTATION){
            axis_X = event.values[0];
            axis_Y = event.values[1];
            axis_Z = event.values[2];
        }
    }

    public void onAccuracyChanged(Sensor sensor, int i) {
        //Log.d("메소드 호출","onAccuracyChanged 메소드 호출");
    }
}

