package com.halbae87.koreanbasicime;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.util.Log;


public class MainActivity extends Activity implements SensorEventListener{

    public static Context mContext;
    public SensorManager sensorManager;
    public Sensor sensor;
    public float axis_X;
    public float axis_Y;
    public float axis_Z;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);

        mContext = this;

        sensorManager = (SensorManager)getSystemService(mContext.SENSOR_SERVICE); // 센서 객체 얻어오기
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_ORIENTATION);// 방향센서 특정으로 가져오기


        //this.startService(new Intent(this,SoftKeyboard.class));
        startService(new Intent(getApplicationContext(),SoftKeyboard.class));
        Log.d("start activity","here");
        Log.d("맨처음 기울기", String.valueOf(axis_X));

        finish();
    }
    public void onResume(){
        super.onResume();
        Log.d("메소드 호출","onResume 메소드 호출 되었다. 여기봐라 ");
        sensorManager.registerListener(this,sensor,SensorManager.SENSOR_DELAY_UI);
    }

    public void onPause(){
        super.onPause();
        sensorManager.unregisterListener(this);
    }

    public void onSensorChanged(SensorEvent event){
        Log.d("메소드 호출","onSensorChanged 메소드 호출되긴했다. ");
        if (event.sensor.getType() == Sensor.TYPE_ORIENTATION){
            Log.d("메소드 호출","onSensorChanged 메소드 안에 들어왔다 !!!!!!!!!!!!!!");
            axis_X = event.values[0];
            axis_Y = event.values[1];
            axis_Z = event.values[2];
        }
    }

    public void onAccuracyChanged(Sensor sensor, int i) {

    }
}

