package com.halbae87.koreanbasicime;

import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.snapshot.Index;

import java.util.HashMap;
import java.util.Map;

public class DatabaseManager {
    int touchedX;
    int touchedY;
    long touchTime;
    float touchPressure;
    float axis_X;
    float axis_Y;
    float axis_Z;
    float touchSize;
    int codenum;
    String formatDate;

    public static int index =0;
    public static Context dContext;

    //private static DatabaseManager Instance;
    public static DatabaseReference mDatabase;

    public DatabaseManager(){

    }
    public DatabaseManager(int touchedX, int touchedY, long touchTime, float touchPressure, float axis_X, float axis_Y, float axis_Z, float touchSize, int codenum, String formatDate){
        this.touchedX = touchedX;
        this.touchedY = touchedY;
        this.touchTime = touchTime;
        this.touchPressure = touchPressure;
        this.axis_X = axis_X;
        this.axis_Y = axis_Y;
        this.axis_Z = axis_Z;
        this.touchSize = touchSize;
        this.codenum = codenum;
        this.formatDate = formatDate;
    }

    public static void writeNewDB(int touchedX, int touchedY, long touchTime, float touchPressure, float axis_X, float axis_Y, float axis_Z, float touchSize, int codenum, String formatDate){
        mDatabase = FirebaseDatabase.getInstance().getReference();

        mDatabase.child(String.valueOf(MainActivity.User)).child("touchedX").setValue(touchedX);
        mDatabase.child(String.valueOf(MainActivity.User)).child("touchedX").setValue(touchedX);
        mDatabase.child(String.valueOf(MainActivity.User)).child("touchedY").setValue(touchedY);
        mDatabase.child(String.valueOf(MainActivity.User)).child("touchTime").setValue(touchTime);
        mDatabase.child(String.valueOf(MainActivity.User)).child("touchPressure").setValue(touchPressure);
        mDatabase.child(String.valueOf(MainActivity.User)).child("axis_X").setValue(axis_X);
        mDatabase.child(String.valueOf(MainActivity.User)).child("axis_Y").setValue(axis_Y);
        mDatabase.child(String.valueOf(MainActivity.User)).child("axis_Z").setValue(axis_Z);
        mDatabase.child(String.valueOf(MainActivity.User)).child("touchSize").setValue(touchSize);
        mDatabase.child(String.valueOf(MainActivity.User)).child("codenum").setValue(codenum);
        mDatabase.child(String.valueOf(MainActivity.User)).child("formatDate").setValue(formatDate);
        mDatabase.child(String.valueOf(MainActivity.User)).child("index").setValue(index);

        index +=1;
    }
}
