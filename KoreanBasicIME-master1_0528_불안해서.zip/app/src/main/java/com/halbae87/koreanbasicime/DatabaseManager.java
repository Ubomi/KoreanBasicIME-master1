package com.halbae87.koreanbasicime;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.firebase.FirebaseApp;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.Exclude;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.snapshot.Index;

import java.util.HashMap;
import java.util.Map;

public class DatabaseManager {
    public static int touchedX;
    public static int touchedY;
    public static long touchTime;
    public static float touchPressure;
    public static float axis_X;
    public static float axis_Y;
    public static float axis_Z;
    public static float touchSize;
    public static int codenum;
    public static String formatDate;
    public static String keyState;

    public static int index =0;
    public static Context dContext;

    public static String S_index;

    //private static DatabaseManager Instance;
    public static DatabaseReference mDatabase;

    public DatabaseManager(){

    }
    public DatabaseManager(int index, int touchedX, int touchedY, long touchTime, float touchPressure, float axis_X, float axis_Y, float axis_Z, float touchSize, int codenum, String formatDate, String keyState){
        this.index = index;
        this.touchedX = touchedX;
        this.touchedY = touchedY;
        this.touchTime = touchTime;
        this.touchPressure = touchPressure;
        this.axis_X = axis_X;
        this.axis_Y = axis_Y;
        this.axis_Z = axis_Z;
        this.touchSize = touchSize;
        this.codenum = codenum;
        this.formatDate = formatDate;
        this.keyState = keyState;
    }
    public Map<String,Object> toMap(){

        HashMap<String,Object> result = new HashMap<>();

        result.put("index",index);
        result.put("touchedX",touchedX);
        result.put("touchedY",touchedY);
        result.put("touchTime",touchTime);
        result.put("touchPressure",touchPressure);
        result.put("axis_X",axis_X);
        result.put("axis_Y",axis_Y);
        result.put("axis_Z",axis_Z);
        result.put("touchSize",touchSize);
        result.put("codenum",codenum);
        result.put("formatDate",formatDate);
        result.put("keyState",keyState);

        return result;
    }
    public static void writeNewDB(boolean add, int codenum, String keyState){
        mDatabase=FirebaseDatabase.getInstance().getReference();
        Map<String,Object> childUpdates = new HashMap<>();
        Map<String, Object> postValues = null;

        touchedX = SoftKeyboard.touchedX;
        touchedY = SoftKeyboard.touchedY;
        touchTime = SoftKeyboard.touchTime;
        touchPressure = SoftKeyboard.touchPressure;
        axis_X = SoftKeyboard.axis_X;
        axis_Y = SoftKeyboard.axis_Y;
        axis_Z = SoftKeyboard.axis_Z;
        touchSize = SoftKeyboard.touchSize;
        //codenum = SoftKeyboard.primaryCode;
        formatDate = SoftKeyboard.formatDate;
        //keyState = SoftKeyboard.keyState;

        if(add){
            DatabaseManager post = new DatabaseManager(index,touchedX,touchedY,touchTime,touchPressure,axis_X,axis_Y,axis_Z,touchSize,codenum,formatDate,keyState);
            postValues = post.toMap();
        }
        S_index = String.valueOf(index);


        childUpdates.put("/"+sensorManage.User +"/"+S_index,postValues);
        mDatabase.updateChildren(childUpdates);
        index +=1;
    }

/*    public static void writeNewDB(int touchedX, int touchedY, long touchTime, float touchPressure, float axis_X, float axis_Y, float axis_Z, float touchSize, int codenum, String formatDate){
        mDatabase = FirebaseDatabase.getInstance().getReference();

        //mDatabase.child(String.valueOf(MainActivity.User)).child("touchedX").setValue(touchedX);

        mDatabase.child(String.valueOf(MainActivity.User)).child("touchedX").setValue(touchedX);
        mDatabase.child(String.valueOf(MainActivity.User)).child("touchedY").setValue(touchedY);
        mDatabase.child(String.valueOf(MainActivity.User)).child("touchTime").setValue(touchTime);
        mDatabase.child(String.valueOf(MainActivity.User)).child("touchPressure").setValue(touchPressure);
        mDatabase.child(String.valueOf(MainActivity.User)).child("axis_X").setValue(axis_X);
        mDatabase.child(String.valueOf(MainActivity.User)).child("axis_Y").setValue(axis_Y);
        mDatabase.child(String.valueOf(MainActivity.User)).child("axis_Z").setValue(axis_Z);
        mDatabase.child(String.valueOf(MainActivity.User)).child("touchSize").setValue(touchSize);
        mDatabase.child(String.valueOf(MainActivity.User)).child("codenum").setValue(codenum);
        mDatabase.child(String.valueOf(MainActivity.User)).child("formatDate").setValue(formatDate);
        mDatabase.child(String.valueOf(MainActivity.User)).child("index").setValue(index);

        index +=1;
    }*/
}
